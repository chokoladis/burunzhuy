--
-- PostgreSQL database dump
--

\restrict 80OM1KzdAMdTXUM7nO91YcKg3uQp1w1X4LW5BqUJI6g3W9twDmKwrzVRJpjyKe1

-- Dumped from database version 18.3 (Debian 18.3-1.pgdg13+1)
-- Dumped by pg_dump version 18.3 (Debian 18.3-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auction_status_enum; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.auction_status_enum AS ENUM (
    'NoActive',
    'Active',
    'Blocked'
);


ALTER TYPE public.auction_status_enum OWNER TO root;

--
-- Name: idea_status_enum; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.idea_status_enum AS ENUM (
    'NoActive',
    'Active',
    'Blocked'
);


ALTER TYPE public.idea_status_enum OWNER TO root;

--
-- Name: user_status_enum; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.user_status_enum AS ENUM (
    'NoActive',
    'Active',
    'Blocked'
);


ALTER TYPE public.user_status_enum OWNER TO root;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: auction; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.auction (
    id bigint NOT NULL,
    idea_id bigint NOT NULL,
    buyer_id bigint NOT NULL,
    status public.auction_status_enum DEFAULT 'Active'::public.auction_status_enum NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    ended_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.auction OWNER TO root;

--
-- Name: auction_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.auction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.auction_id_seq OWNER TO root;

--
-- Name: auction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.auction_id_seq OWNED BY public.auction.id;


--
-- Name: group; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."group" (
    id bigint NOT NULL,
    name character varying(50) NOT NULL,
    code character varying(50) NOT NULL
);


ALTER TABLE public."group" OWNER TO root;

--
-- Name: group_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.group_id_seq OWNER TO root;

--
-- Name: group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.group_id_seq OWNED BY public."group".id;


--
-- Name: idea; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.idea (
    id bigint NOT NULL,
    seller_id bigint NOT NULL,
    title character varying(70) NOT NULL,
    short_description character varying NOT NULL,
    preview jsonb NOT NULL,
    status public.idea_status_enum DEFAULT 'Active'::public.idea_status_enum NOT NULL,
    full_description text NOT NULL,
    files jsonb,
    enter_cost numeric,
    full_price numeric
);


ALTER TABLE public.idea OWNER TO root;

--
-- Name: idea_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.idea_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.idea_id_seq OWNER TO root;

--
-- Name: idea_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.idea_id_seq OWNED BY public.idea.id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."user" (
    id bigint NOT NULL,
    name character varying(50) NOT NULL,
    second_name character varying(150),
    email character varying(150) NOT NULL,
    description text,
    group_id bigint NOT NULL,
    status public.user_status_enum DEFAULT 'NoActive'::public.user_status_enum NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    phone character varying(15) NOT NULL
);


ALTER TABLE public."user" OWNER TO root;

--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_id_seq OWNER TO root;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: auction id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.auction ALTER COLUMN id SET DEFAULT nextval('public.auction_id_seq'::regclass);


--
-- Name: group id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."group" ALTER COLUMN id SET DEFAULT nextval('public.group_id_seq'::regclass);


--
-- Name: idea id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.idea ALTER COLUMN id SET DEFAULT nextval('public.idea_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Data for Name: auction; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.auction (id, idea_id, buyer_id, status, created_at, ended_at) FROM stdin;
\.


--
-- Data for Name: group; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."group" (id, name, code) FROM stdin;
1	users	users
\.


--
-- Data for Name: idea; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.idea (id, seller_id, title, short_description, preview, status, full_description, files, enter_cost, full_price) FROM stdin;
7	5	говно	Делаем говнокоин и зарабатываем на гоях, де летс гоу бойз	"{\\"test\\":\\"data\\"}"	Active	Делаем говнокоин и зарабатываем на гоях. суть проста в одном три девятом королевстве в 3 девятом государстве	\N	100	1000
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."user" (id, name, second_name, email, description, group_id, status, created_at, updated_at, phone) FROM stdin;
5	testtt	\N	test@mail.ru	\N	1	NoActive	2026-04-10 14:20:21.087226	2026-04-10 14:20:21.087226	12341
6	223	\N	test@mail.ru	\N	1	NoActive	2026-04-10 14:37:02.719259	2026-04-10 14:37:02.719259	1234
\.


--
-- Name: auction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.auction_id_seq', 1, false);


--
-- Name: group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.group_id_seq', 1, true);


--
-- Name: idea_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.idea_id_seq', 7, true);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.user_id_seq', 6, true);


--
-- Name: group PK_256aa0fda9b1de1a73ee0b7106b; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."group"
    ADD CONSTRAINT "PK_256aa0fda9b1de1a73ee0b7106b" PRIMARY KEY (id);


--
-- Name: idea PK_5096f543c484b349f5234da9d97; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.idea
    ADD CONSTRAINT "PK_5096f543c484b349f5234da9d97" PRIMARY KEY (id);


--
-- Name: auction PK_9dc876c629273e71646cf6dfa67; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.auction
    ADD CONSTRAINT "PK_9dc876c629273e71646cf6dfa67" PRIMARY KEY (id);


--
-- Name: user PK_cace4a159ff9f2512dd42373760; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT "PK_cace4a159ff9f2512dd42373760" PRIMARY KEY (id);


--
-- Name: auction REL_167213bc23a1caf7b1f5cbeea0; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.auction
    ADD CONSTRAINT "REL_167213bc23a1caf7b1f5cbeea0" UNIQUE (idea_id);


--
-- Name: auction FK_167213bc23a1caf7b1f5cbeea03; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.auction
    ADD CONSTRAINT "FK_167213bc23a1caf7b1f5cbeea03" FOREIGN KEY (idea_id) REFERENCES public.idea(id) ON DELETE CASCADE;


--
-- Name: user FK_3c29fba6fe013ec8724378ce7c9; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT "FK_3c29fba6fe013ec8724378ce7c9" FOREIGN KEY (group_id) REFERENCES public."group"(id) ON DELETE CASCADE;


--
-- Name: auction FK_a4ead1d1ab72b90a66e63fb5854; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.auction
    ADD CONSTRAINT "FK_a4ead1d1ab72b90a66e63fb5854" FOREIGN KEY (buyer_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: idea FK_dddd4462adc790ca985360db6d4; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.idea
    ADD CONSTRAINT "FK_dddd4462adc790ca985360db6d4" FOREIGN KEY (seller_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 80OM1KzdAMdTXUM7nO91YcKg3uQp1w1X4LW5BqUJI6g3W9twDmKwrzVRJpjyKe1

